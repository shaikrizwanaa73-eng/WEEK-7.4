# Producer-Consumer Problem in Java

## AIM
Implement the Producer-Consumer problem using a shared `LinkedList`, `synchronized`, `wait()`, and `notify()`.

## File
- `ProducerConsumerDemo.java`

## Compile and run
Open Terminal in this folder and run:

```bash
javac ProducerConsumerDemo.java
java ProducerConsumerDemo
```

The program runs indefinitely. Stop it with **Ctrl+C**.

## Notes
- Buffer capacity is fixed at 2.
- The producer waits while the buffer is full.
- The consumer waits while the buffer is empty.
- Output order may vary because the threads execute concurrently.
